=====================================================================
  MORTAL KOMBAT: ULTIMATE KOMPLETE EDITION LAUNCHER  -  v1.3.1
  An unofficial modern launcher for Mortal Kombat Komplete Edition (PC, Steam v1.07)
=====================================================================

FEATURES
  - Vulkan (DXVK), DirectX 11 / 12 (dgVoodoo2) or the original DirectX 9 renderer
  - Fullscreen, Borderless fullscreen and Windowed modes (fixed windowed mode)
  - Any resolution incl. ultrawide, monitor selection
  - 60 FPS limiter, VSync, texture filtering / anti-aliasing overrides
  - 6 graphics presets (Potato, Console, Vanilla, Optimized, Ultra, Maximum)
  - Skip intro movies, online matchmaking distance
  - Ryzen freeze fix, high CPU priority, disable fullscreen optimizations
  - Settings profiles you can share, DLC Manager shortcuts, diagnostics report
  - 12 themes (incl. dark modes), custom accent and text colours
  - Restore Vanilla: undo every change the launcher made with one click

INSTALL
  1. Open your game folder:
       Steam > right-click Mortal Kombat Komplete Edition > Manage > Browse local files
     then open the "DiscContentPC" folder.
  2. Rename the original "MKLauncher.exe" to "MKLauncher_Original.exe".
     (The launcher's ORIGINAL LAUNCHER button opens it.)
  3. Copy everything from this zip's "DiscContentPC" folder into the game's
     "DiscContentPC" folder. Allow it to overwrite dgVoodoo.conf if asked.
  4. Start the game from Steam (or run MKLauncher.exe). The first time, the
     launcher picks settings for your PC - review them and click START GAME.

RECOMMENDED
  Display Mode: Borderless   Renderer: Vulkan (DXVK)   Vertical Sync: Enabled
  (DirectX 11 / 12 render some God of War content - Kratos and his stage - black.)

TIPS
  - Hover any option for an explanation.
  - Enter = start game, Esc = close launcher.
  - Quick launch (Settings tab): starts the game straight away. Hold SHIFT
    while opening the launcher to get the window back.
  - The game's speed is tied to 60 FPS: lower frame limits play in slow motion.
  - The first match on Vulkan can stutter briefly while shaders are built.

UNINSTALL
  1. Open the launcher > TOOLS > RESTORE VANILLA.
  2. Delete MKLauncher.exe, D3D9.dgvoodoo.dll, D3D9.dxvk.dll, dxvk.conf,
     dgVoodoo.conf, MKKE_Launcher.ini and the logs / Profiles / Licenses folders.
  3. Rename MKLauncher_Original.exe back to MKLauncher.exe.

UPDATES
  The launcher checks for new versions at startup (Settings tab) and with
  ABOUT > CHECK FOR UPDATES. Releases: https://github.com/piercejonathan153-lab/MKU-KEL/releases

REPORTING PROBLEMS
  TOOLS > DIAGNOSTICS creates a report - send it along with the newest file
  from TOOLS > LAUNCHER LOGS.

CREDITS
  Vulkan rendering: DXVK by Philip Rebohle and contributors (zlib license)
  DirectX 11 / 12 rendering: dgVoodoo2 by Dege
  Design inspired by BmLauncher by neatodev
  Mortal Kombat is a trademark of Warner Bros. Entertainment Inc.
  This is an unofficial fan tool, not affiliated with WB Games or NetherRealm Studios.
